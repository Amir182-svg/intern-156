# Project Presentation: Inquisitors Society Chatbot

---

## Slide 1: Title & Overview
### **Inquisitors Society Intelligent Portal**
*AI-Powered Local Assistant for UET Lahore students*
* **Presenter**: [Your Name/Group ID]
* **Objective**: Streamlining student access to Courses, Internships, Events, and Careers.

---

## Slide 2: Problem Statement
* Students struggle to find updated listings of workshops, CSS prep, and internship options.
* Hosting standard cloud-based LLM chatbots (like OpenAI API) requires ongoing license fees and API keys.
* Running heavy local models (e.g., Llama 2 7B) heats up standard laptops and drains the battery.

---

## Slide 3: The Solution
* **Lightweight Local AI**: Standardized on Ollama with `qwen2.5:0.5b` (uses less than 500MB RAM, runs cool on CPUs).
* **Double-Mode Premium Portal**: Brand new dark/light-themed user dashboard.
* **Auto-Launch Scripting**: Single terminal command starts the AI, hosts the web app, and opens the browser.
* **Social Connections**: One-click redirection to official LinkedIn, Facebook, and Instagram profiles.

---

## Slide 4: System Architecture
* **Frontend**: HTML5 / Premium CSS Variables / ES6 JavaScript.
* **Backend**: Node.js / Express.js (serves static assets and acts as the REST API controller).
* **AI engine**: Hybrid Search Engine -> checks FAQ database -> falls back to local Ollama API.

---

## Slide 5: Key Features Demo
* **Light/Dark Mode**: High contrast transition saved in local storage.
* **Information Modals**: Interactive detail cards pop up when browsing Course outlines, Active Internships, and Mock Interviews.
* **Social Integration**: LinkedIn, Facebook, and Instagram shortcuts.

---

## Slide 6: Conclusion & Future Scope
* **Result**: A highly responsive, 100% free, private, and local chatbot prototype.
* **Next Steps**:
  1. Link with active university database.
  2. Implement local speech-to-text input.
