# Inquisitors Society Chatbot - Technical Documentation

## 1. System Overview
The Inquisitors Society Chatbot is a hybrid-intelligence assistant platform built to serve the students, teachers, mentors, and corporate partners of the Inquisitors Society at UET Lahore. It combines a local rule-based FAQ knowledge base search engine for fast, 100% accurate responses to common queries, with a locally run Large Language Model (LLM) powered by Ollama (`qwen2.5:0.5b`) for general fallback intelligence.

## 2. System Architecture

```text
  +-------------------------------------------------------------+
  |                        Web Browser                          |
  |   (HTML5 / Premium CSS Variable-based Dark-Light Theme / JS)|
  +------------------------------+------------------------------+
                                 |  HTTPS POST (JSON)
                                 v
  +-------------------------------------------------------------+
  |                        Node.js Server                       |
  |   - Serves static Frontend files                             |
  |   - Standardizes inputs and matches FAQ keywords             |
  |   - Auto-spawns background processes (Ollama model)         |
  +--------+------------------------------------------+---------+
           |                                          |
           | Match Found                              | Fallback / Out of Scope
           v                                          v
+--------------------+                     +--------------------+
|  FAQ Knowledge     |                     |    Local Ollama    |
|  Base Json         |                     |   (qwen2.5:0.5b)   |
+--------------------+                     +--------------------+
```

## 3. Technology Stack
* **Frontend**: HTML5, Vanilla CSS3 (dynamic HSL variable-based styling, glassmorphism, responsive media queries), Vanilla ES6 JavaScript.
* **Backend**: Node.js, Express.js (serving static files and REST API routing), native `fetch` client.
* **AI Engine**: Ollama (model: `qwen2.5:0.5b` - 0.5 billion parameter model requiring minimal memory and CPU to avoid system overheating).

## 4. Key Functions & Code Logic

### 4.1 Hybrid Matcher Routing
When a message is received at `/api/chat`, the backend:
1. Searches the `knowledge.json` file for exact question matches or keyword overlaps (scoring threshold system).
2. If scored high enough, it returns the stored answer, hyperlinks, and suggestions instantly.
3. If no match is found, it directs the query to the local Ollama chat API (`/api/chat`) at `http://127.0.0.1:11434`.

### 4.2 Auto-Start and Browser Initialization
Upon server start (`server.js`):
* `child_process.exec('ollama run qwen2.5:0.5b')` is invoked to load the model into memory.
* `child_process.exec('start http://localhost:5000')` is called to launch the user's default browser automatically.

## 5. Security & Fallbacks
* **Graceful Failure**: If Ollama is offline or not installed, the AI route returns a default friendly fallback message from `knowledge.json` instead of returning a 500 server error.
* **No API Keys Needed**: Operates 100% locally by default, removing external credential risks and payment setups.
