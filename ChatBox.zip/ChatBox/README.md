# Inquisitors Society Portal & Chatbot

An intelligent, AI-powered student portal and chatbot designed to assist students, teachers, mentors, and partners with information about the **Inquisitors Society** platform at UET Lahore.

The chatbot answers questions about **courses, events, internships, and career development** using a hybrid approach: a local knowledge base combined with a locally hosted LLM via **Ollama**.

---

## Key Features

- **Double-Mode Premium UI** – Sleek, fully responsive design with dynamic **Dark Mode** and **Light Mode** options.
- **Interactive Detail Modals** – Click on any portal pillar (Courses, Internships, Events, Career) to view lists of current opportunities in a glassmorphic overlay.
- **One-Command Auto Start** – The backend server automatically hosts the static frontend files, starts your local Ollama model in the background, and opens your default web browser to the portal page.
- **Hybrid AI Engine** – Instantly answers common questions via a fast local FAQ knowledge base, falling back to local Ollama AI for complex queries.
- **Direct Social Shortcuts** – Brand-themed direct access buttons for the society's **LinkedIn**, **Facebook**, and **Instagram** handles.

---

## Setup and Running

### 1. Download and Run Ollama
If you don't have Ollama installed, download it from [ollama.com](https://ollama.com). 

Before launching the app, run the following commands in your Command Prompt/terminal to pull the ultra-lightweight AI model:
```bash
ollama pull qwen2.5:0.5b
```

### 2. Startup Command
Navigate to the `backend` directory, install packages, and start the app:
```bash
cd backend
npm install
npm start
```

### What happens when you run `npm start`?
- The backend server boots up on port `5000`.
- The system automatically triggers `ollama run qwen2.5:0.5b` in the background (no need to open a separate terminal!).
- Your default web browser will **automatically open** to the student portal at `http://localhost:5000/`.

---

## Project Structure

```text
├── backend/
│   ├── server.js          # Node.js backend (FAQ search engine, static file server, Ollama API bridge)
│   ├── .env               # Server environment configurations
│   └── package.json       # Backend package dependencies
├── frontend/
│   ├── index.html         # Portal HTML layout
│   ├── style.css          # Premium Dark/Light stylesheets
│   ├── script.js          # Interactive modals, theme toggle, and API request handling
│   └── inquisitors-logo.png
├── knowledge-base/
│   └── knowledge.json     # FAQ database
└── docs/
    ├── technical_documentation.md   # Complete setup documentation
    └── presentation.md              # Project presentation slides
```
